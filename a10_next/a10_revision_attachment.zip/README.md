A10 revision attachment. Commit 308a9e5. GPU NVIDIA A10, device cuda:0, float64, four chains. Fixed-step and the pilot use h/sigma^2 = 0.01.

fixed_step_per_cell.csv
    24 cells. Retained steps per chain, chain count, pooled bulk ESS, pooled raw-mean ESS, production elapsed seconds, and the timed joint-step cost. stored_ess_per_second is the value written by the jobs. bulk_ess_per_timed_batch_second divides that bulk ESS by steps_per_chain times seconds_per_joint_step.

pilot_timing_blocks.csv
    Five measured blocks for deep_m0032_r0 and five for deep_m0256_r0. Length-finding probes are excluded.

pilot_comparison.csv
    cost_ratio 1.135475. Archived training-loss bulk ESS ratio 2.068404. ESS/s ratio 1.821621, block range 1.812648 to 1.830097. Decision wide. This ratio is unchanged by the factor of four.

calculation.md
    The lines that produce ess_per_second and cost_ratio.

tuning_candidates.csv
    Step, replicate, and loss ESS per transition. Acceptance, timing, and held-out prediction ESS were not stored for these candidates.

prior_start_batches.csv
    Eight completed batches of 8192 steps for each of 12 cells, with acceptance. Independent posterior reference means and SDs were not computed.

robustness_and_geometry.csv
    Sampler completion, elapsed time, and acceptance for the robustness pairs, the prior-only pair, and the six geometry-pilot cells. Per-probe metrics and the geometry discrepancy were not computed.

prediction_acf_check.json
    status raw_series_absent. The stage file was not in the checkout, so test_prob_0 was not rebuilt.

replay_s1_with_a10_cost.csv
    Archived 102400-step rank bulk ESS for loss V and eight held-out probabilities, paired with that cell's measured A10 joint-step cost. bulk_ess_per_timed_batch_second uses the four-chain batch duration. stored_style_ess_per_second also divides by the chain count.

replay_endpoint_ratios.csv
    Deep 32 versus 256 and shallow 64 versus 4096, each replicate and each observable. Archived bulk ESS ratio divided by the measured cost ratio. The chain-count factor cancels. This is not the 8192-step rate.
