The stored short-window rate

The field loss_rate.ess_per_second in each fixed-step summary is

    ess_mean_raw(loss) / n_total / seconds_per_joint_step

n_total is 4 chains times 8192 retained steps. seconds_per_joint_step is the timed cost of one joint step of those four chains. The same number is stored as timing.seconds_per_transition. Dividing by n_total and then by that joint-step time divides the pooled raw-mean ESS by four times the timed batch duration.

The bulk rate for the same four-chain batch, without that extra factor, is

    ess_bulk / production_elapsed_s
    ess_bulk / (steps_per_chain * seconds_per_joint_step)

The first denominator is the production clock. The second is the separate timing clock. Both are columns in fixed_step_per_cell.csv. stored_divided_by_bulk_timed is about 1/4 when the raw-mean ESS and the bulk ESS are close.

Source of the stored rate, src/bnn_geometry/revision/efficiency.py, scalar_rate:

    ess, lag = ess_mean_raw(x)
    per_t = ess_per_transition(ess, x.size)      # ess / (chains * steps)
    per_s = per_t / seconds_per_transition       # seconds_per_transition is one joint step

Source of the call, src/bnn_geometry/revision/runner.py:

    scalar_rate(loss, seconds_per_transition=summary["timing"]["seconds_per_transition"])

timing.seconds_per_transition is set equal to seconds_per_joint_step.

Pilot cost ratio, src/bnn_geometry/revision/efficiency.py, timed_width_comparison:

    cost = wide_seconds_per_joint_step / narrow_seconds_per_joint_step
    ess_per_second_ratio = archived_ess_ratio / cost

The pilot ratio holds the archived training-loss bulk ESS fixed. Both widths use four chains, so the factor of four cancels. The ten block rows are in pilot_timing_blocks.csv.
